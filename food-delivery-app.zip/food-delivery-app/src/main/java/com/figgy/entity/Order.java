package com.figgy.entity;

import java.util.List;

public class Order {
  Integer orderId;
  List<FoodItem> foodItemList;
  Restaurant restaurant;

  public Integer getOrderId() {
    return orderId;
  }

  public void setOrderId(Integer orderId) {
    this.orderId = orderId;
  }

  public List<FoodItem> getFoodItemList() {
    return foodItemList;
  }

  public void setFoodItemList(List<FoodItem> foodItemList) {
    this.foodItemList = foodItemList;
  }

  public Restaurant getRestaurant() {
    return restaurant;
  }

  public void setRestaurant(Restaurant restaurant) {
    this.restaurant = restaurant;
  }


  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Order [");
    sb.append("orderId=").append(orderId);
    sb.append(", foodItemList=").append(foodItemList);
    sb.append(", restaurant=").append(restaurant);
    sb.append(']');
    return sb.toString();
  }
}
