package com.figgy.entity;

import java.util.List;

public class Restaurant {
  Menu menu;
  Integer id;
  Integer totalCapacity;
  List<Order> orderList;

  public Menu getMenu() {
    return menu;
  }

  public void setMenu(Menu menu) {
    this.menu = menu;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getTotalCapacity() {
    return totalCapacity;
  }

  public void setTotalCapacity(Integer totalCapacity) {
    this.totalCapacity = totalCapacity;
  }

  public List<Order> getOrderList() {
    return orderList;
  }

  public void setOrderList(List<Order> orderList) {
    this.orderList = orderList;
  }

  public Restaurant(Integer id, Menu menu, Integer totalCapacity) {
    this.menu = menu;
    this.id = id;
    this.totalCapacity = totalCapacity;
  }

  public void processOrder(Order order) {
    int asked =  0 ;

    for(FoodItem foodItem: order.foodItemList){
      asked+= foodItem.getQty();
    }
    totalCapacity -= asked;

  }

   void reAllocateCapacity(List<FoodItem> foodItemList) {

  }


  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Restaurant [");
    sb.append("menu=").append(menu);
    sb.append(", id=").append(id);
    sb.append(", totalCapacity=").append(totalCapacity);
    sb.append(", orderList=").append(orderList);
    sb.append(']');
    return sb.toString();
  }
}
