package com.figgy.entity;

import com.figgy.selection.SelectionStrategy;
import com.figgy.selection.StragetySelector;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AppSystem {
  private static int counter = 0;
  List<Order> activeOrderList = new ArrayList<>();
  List<Restaurant> restaurantList = new ArrayList<>();


  public static AppSystem getInstance() {
    //TODO:singleton implementation
    if (counter == 0) {

    }
    return null;
  }

  public void addRestaurant(Restaurant restaurant) {
    //TODO: Vaidate Restaurant
    restaurantList.add(restaurant);
  }

 public void updateMenu(Integer restId, Menu menu) {
    List<Restaurant> restaurants =
        restaurantList.stream().filter(rest -> rest.id.equals(restId)).collect(Collectors.toList());
    if (restaurants.isEmpty()) {
//    throw new NoRestaurantExcpetion("unable to find restaurant with id : {0}",restId);
    }

  }

  public void bookOrder(Order order) {
    SelectionStrategy selectionStrategy = StragetySelector.select(1);
    //get RestaurantId->orders mapping
    List<Order> orderList = selectionStrategy.getIndividualOrders(order, restaurantList);
    activeOrderList.addAll(orderList);

  }

  public void fullFillOrder(Integer orderId) {
    int orderIndx = getOrderIndx(orderId);
    Order order = activeOrderList.get(orderIndx);
    Restaurant restaurant = order.restaurant;
    restaurant.reAllocateCapacity(order.foodItemList);
  }

  int getOrderIndx(Integer orderId) {
    for (int i = 0; i < activeOrderList.size(); i++) {
      if (orderId.equals(activeOrderList.get(i).orderId)) {
        return i;
      }
    }
    return -1; //means invalid order id
  }


  public void printOrderList(){
    System.out.println(activeOrderList.toString());
  }


}
