package com.figgy.entity;

public class FoodItem {
  String name;
  Double price;
  Integer qty;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Double getPrice() {
    return price;
  }

  public void setPrice(Double price) {
    this.price = price;
  }

  public Integer getQty() {
    return qty;
  }

  public void setQty(Integer qty) {
    this.qty = qty;
  }


  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("FoodItem [");
    sb.append("name=").append(name);
    sb.append(", price=").append(price);
    sb.append(", qty=").append(qty);
    sb.append(']');
    return sb.toString();
  }
}
