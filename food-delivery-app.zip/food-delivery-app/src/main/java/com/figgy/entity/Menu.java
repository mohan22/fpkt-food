package com.figgy.entity;

import java.util.Map;

public class Menu {
  Map<String,FoodItem> menuItem;

  public Map<String, FoodItem> getMenuItem() {
    return menuItem;
  }

  public void setMenuItem(Map<String, FoodItem> menuItem) {
    this.menuItem = menuItem;
  }

  public Menu(Map<String,FoodItem> menuItem){
    this.menuItem = menuItem;
  }


  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Menu [");
    sb.append("menuItem=").append(menuItem);
    sb.append(']');
    return sb.toString();
  }
}
