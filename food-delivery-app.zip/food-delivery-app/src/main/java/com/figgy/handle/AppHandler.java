package com.figgy.handle;

import com.figgy.entity.AppSystem;
import com.figgy.entity.FoodItem;
import com.figgy.entity.Menu;
import com.figgy.entity.Order;
import com.figgy.entity.Restaurant;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class AppHandler {

  public static void main(String args[]){
    AppSystem appSystem = new AppSystem();
    FoodItem biryani = new FoodItem();
    biryani.setName("biryani");
    biryani.setPrice(100.0);

    FoodItem idly = new FoodItem();
    idly.setName("idly");
    idly.setPrice(20.0);

    Map<String,FoodItem> foodItemMap = new HashMap<>();
    foodItemMap.put("biryani",biryani);
    foodItemMap.put("idly",idly);

    Menu menu = new Menu(foodItemMap);

    Restaurant restaurant = new Restaurant(1,menu,90);
    appSystem.addRestaurant(restaurant);

    Order order = new Order();
    order.setOrderId(1);
    order.setRestaurant(restaurant);

    FoodItem orderFoodItem = new FoodItem();
    orderFoodItem.setName("idly");
    orderFoodItem.setQty(50);
    orderFoodItem.setPrice(20.0);

    order.setOrderId(1);
    order.setFoodItemList(Arrays.asList(orderFoodItem));
    appSystem.bookOrder(order);

    appSystem.printOrderList();




//    Restaurant restaurant = new Restaurant()




  }
}
