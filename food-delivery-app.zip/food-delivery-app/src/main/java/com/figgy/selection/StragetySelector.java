package com.figgy.selection;

public class StragetySelector {

  private StragetySelector() {
  }

  public static SelectionStrategy select(int flag) {
    if (flag == 1) {
      return new LowestPriceFirst();
    }
    System.out.println("Given strategy is not yet configured in the AppSystem ::" + flag);
    return null;
  }
}
