package com.figgy.selection;

import com.figgy.entity.FoodItem;
import com.figgy.entity.Order;
import com.figgy.entity.Restaurant;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class LowestPriceFirst implements SelectionStrategy{
  @Override
  public List<Order> getIndividualOrders(Order parentOrder,List<Restaurant> restaurantList) {
    //TODO: Algo
    Order child = parentOrder;
    Restaurant target = restaurantList.get(0);
    target.processOrder(child);
    parentOrder.setRestaurant(restaurantList.get(0));
    return Arrays.asList(child);
  }
}
