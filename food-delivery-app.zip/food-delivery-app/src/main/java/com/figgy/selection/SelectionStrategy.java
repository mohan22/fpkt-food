package com.figgy.selection;

import com.figgy.entity.Order;
import com.figgy.entity.Restaurant;

import java.util.List;
import java.util.Map;

public interface SelectionStrategy {
  public List<Order> getIndividualOrders(Order parentOrder,List<Restaurant> restaurantList);
}
